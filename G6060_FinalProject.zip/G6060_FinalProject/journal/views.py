from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db import transaction
from .models import JournalEntry
from .forms import JournalEntryForm

# Lab 2 & 6: Main View protected by login
@login_required
def index(request):
    if request.method == "POST":
        form = JournalEntryForm(request.POST)
        if form.is_valid():
            # Lab 7: Safe database transactions
            with transaction.atomic():
                entry = form.save(commit=False)
                entry.author = request.user
                entry.save()
            return redirect('index')
    else:
        form = JournalEntryForm()

    # Lab 6: Security - only filter entries for the current user
    entries = JournalEntry.objects.filter(author=request.user)
    return render(request, 'journal/index.html', {'entries': entries, 'form': form})

# Lab 10: Web Services (JSON Endpoint)
@login_required
def journal_api(request):
    my_entries = JournalEntry.objects.filter(author=request.user)
    data = {
        "user": request.user.username,
        "entries": list(my_entries.values('title', 'content', 'created_at')),
        "status": "success"
    }
    return JsonResponse(data)